﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SaveOpen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        Int64 n=0;
        Int64 factorial =1;
        
        private void button1_Click(object sender, EventArgs e)
        {

            n = Int64.Parse(textBox1.Text);

            for (int i = 1; i <= n; ++i)
            {
                factorial *= i;
            }
            textBox2.Text = factorial.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox1.Clear();
            factorial = 1;
            n = 0;
        }

        private void otwórzToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
         
    }
}
